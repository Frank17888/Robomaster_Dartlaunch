#ifndef __SOLENOID_H
#define __SOLENOID_H

void pullworkTask(void);
void rechargeTask(void);
void flag_Initialize(void);
int Range_In(float Range,float Actual,float Target);

#endif
