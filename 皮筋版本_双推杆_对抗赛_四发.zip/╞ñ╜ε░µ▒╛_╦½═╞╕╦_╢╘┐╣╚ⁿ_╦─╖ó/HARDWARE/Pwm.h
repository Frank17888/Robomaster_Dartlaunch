#ifndef __PWM_H__
#define __PWM_H__

void Pitch_TIM3_Config(void);
void MG995_TIM5_Config(void);
void motor_putter_Config(void);
void Putter_Move_Updown(int updown);
#endif
