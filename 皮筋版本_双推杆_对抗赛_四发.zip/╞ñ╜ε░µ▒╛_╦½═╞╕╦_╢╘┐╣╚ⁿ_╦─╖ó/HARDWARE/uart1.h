#ifndef __UART4_H
#define __UART4_H

#include "main.h"

#define JudgeBufBiggestSize 45
#define SEND_MAX_SIZE 		60

void uart1_Configuration(void);

#endif
