#ifndef __DELAY_H
#define __DELAY_H

void delay_us(int tim);
void delay_ms(int tim);
void TIM6_Config(void);
void TIM7_Config(void);

#endif
