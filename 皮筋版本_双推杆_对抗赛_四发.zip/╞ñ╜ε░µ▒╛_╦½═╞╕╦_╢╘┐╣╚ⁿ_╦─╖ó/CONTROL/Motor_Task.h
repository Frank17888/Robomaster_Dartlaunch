#ifndef __MOTORTASK_H__
#define __MOTORTASK_H__

#include "main.h"

void Motor_Cal(void);
void Pid_Speed_Cal(void);
void Pid_Speed_Init(void);


#endif
